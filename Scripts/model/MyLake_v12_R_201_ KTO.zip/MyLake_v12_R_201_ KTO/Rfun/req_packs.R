require(chron) # heatflux, sordana1
require(akima) # albedo_mod
require(R.matlab) # albedo_mod

